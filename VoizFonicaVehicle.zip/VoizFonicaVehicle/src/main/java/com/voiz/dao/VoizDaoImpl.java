package com.voiz.dao;

import java.util.HashMap;
import java.util.Map;

import com.voiz.bean.Vehicle;

public class VoizDaoImpl implements VoizDao {
	Vehicle vehicle=new Vehicle();
	HashMap<Integer, Vehicle> map=new HashMap<Integer, Vehicle>();
	HashMap<Integer, Vehicle> map1=new HashMap<Integer, Vehicle>();

	
	
/*	public VoizDaoImpl() {
		map1.put(111111, new Vehicle("2wheeler", 3, 123654789963L, 8179122778L));
		map1.put(111112, new Vehicle("4wheeler", 4, 987654321987L, 9949637758L));
		map1.put(111113, new Vehicle("2wheeler", 2, 789654123852L, 7369982038L));
	}*/
	
	
	
	public boolean registration(Vehicle vehicle) {
		boolean value=false;
		map.put(vehicle.getVehicleNo(), new Vehicle(vehicle.getVehicleType(), vehicle.getInsurancePeriod(), vehicle.getAadharNo(), vehicle.getMobileNo()));
		value=true;
	/*	for(Map.Entry m: map.entrySet()) {
			  System.out.println(m.getKey());
		  }*/
		return value;
			
		
	}

	
	

}
