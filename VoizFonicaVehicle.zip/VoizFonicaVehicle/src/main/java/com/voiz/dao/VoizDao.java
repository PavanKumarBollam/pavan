package com.voiz.dao;

import com.voiz.bean.Vehicle;

public interface VoizDao {

	boolean registration(Vehicle vehicle);

}
