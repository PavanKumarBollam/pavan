package com.voiz.bean;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Vehicle {
	
		private int vehicleNo;
		private String vehicleType;
		private long aadharNo;
		private long mobileNo;
		private int insurancePeriod;
		 
		   
		public Vehicle(String vehicleType2, int i, long aadharNo2, long mobileNo2) {
			// TODO Auto-generated constructor stub
		}
		
		public Vehicle() {
			// TODO Auto-generated constructor stub
		}
		

		

		public int getVehicleNo() {
			return vehicleNo;
		}
		public void setVehicleNo(int vehicleNo) {
			this.vehicleNo = vehicleNo;
		}
		public String getVehicleType() {
			return vehicleType;
		}
		public void setVehicleType(String vehicleType) {
			this.vehicleType = vehicleType;
		}
		public long getAadharNo() {
			return aadharNo;
		}
		public void setAadharNo(long aadharNo) {
			this.aadharNo = aadharNo;
		}
		public long getMobileNo() {
			return mobileNo;
		}
		public void setMobileNo(long mobileNo) {
			this.mobileNo = mobileNo;
		}

		public int getInsurancePeriod() {
			return insurancePeriod;
		}

		public void setInsurancePeriod(int insurancePeriod) {
			this.insurancePeriod = insurancePeriod;
		}
}
		
