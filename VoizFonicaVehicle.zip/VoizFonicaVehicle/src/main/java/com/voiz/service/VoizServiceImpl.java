package com.voiz.service;

import com.voiz.bean.Vehicle;
import com.voiz.dao.VoizDao;
import com.voiz.dao.VoizDaoImpl;

public class VoizServiceImpl implements VoizService{

	VoizDao dao=new VoizDaoImpl();
	
	public boolean registration(Vehicle vehicle) {
		
		return dao.registration(vehicle);
	}

}
