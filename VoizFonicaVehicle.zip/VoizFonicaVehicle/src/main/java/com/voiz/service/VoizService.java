package com.voiz.service;

import com.voiz.bean.Vehicle;

public interface VoizService {

	boolean registration(Vehicle vehicle);

}
