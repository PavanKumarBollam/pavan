package com.voiz.ui;

import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.voiz.bean.Vehicle;
import com.voiz.service.VoizService;
import com.voiz.service.VoizServiceImpl;

public class MainUi {
	Vehicle vehicle=new Vehicle();
	VoizService service=new VoizServiceImpl();
	
	public void display() {
		

		System.out.println("Enter 1 for Vehicle Insurance Registration\n 2 for Insurance validity check ");
		Scanner scan=new Scanner(System.in);
		int i=scan.nextInt();
		switch(i) {
		
		case 1 :
			System.out.println("Enter Vehicle Number");
			vehicle.setVehicleNo(scan.nextInt());
			System.out.println("Enter Vehicle Type");
			vehicle.setVehicleType(scan.next());
			System.out.println("Enter Insurance Period");
			DateTimeFormatter date = DateTimeFormatter.ofPattern("yyyy/MM/dd");  
			   LocalDateTime now = LocalDateTime.now();  
			 System.out.println(date.format(now));
			   vehicle.setInsurancePeriod(scan.nextInt());
			   System.out.println(vehicle.getInsurancePeriod());
			System.out.println("Enter aadhar Number");
			vehicle.setAadharNo(scan.nextLong());
			System.out.println("Enter Mobile Number");
			vehicle.setMobileNo(scan.nextLong());
			service.registration(vehicle);
			
		case 2 :
			System.out.println("Enter Vehicle Number");
			vehicle.setVehicleNo(scan.nextInt());
		
		case 3 :
			System.exit(0);
		}
	}
	
	
	
	public static void main(String[] args) {
		MainUi main=new MainUi();
		main.display();
	}
}