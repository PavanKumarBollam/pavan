package com.capgemini.testingapp;

import java.util.LinkedList;

import com.capgemini.testingapp.exception.EmptyMyStackException;

public class MyStack<T> {
	
	private LinkedList<T> data;
	
	public MyStack() {
		data = new LinkedList<>();
	}

	public long size() {
		return data.size();
	}

	public void push(T element) {
		data.addLast(element);
	}

	public T pop() throws EmptyMyStackException {
		if(size() == 0)
			throw new EmptyMyStackException("Stack is empty.");
		return data.removeLast();
	}

	public T peek() throws EmptyMyStackException {
		if(size() == 0)
			throw new EmptyMyStackException("Stack is empty.");
		return data.getLast();
	}
}
