package com.capgemini.testingapp.tests;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.capgemini.testingapp.MyStack;
import com.capgemini.testingapp.exception.EmptyMyStackException;

public class MyStackTest {
	
	private MyStack<Integer> stack;
	
	@Before
	public void setUp() {
		stack = new MyStack<>();
	}

	@Test
	public void testNewStackSizeIsZero() {
		assertEquals(0, stack.size());
	}
	
	@Test
	public void testPushOperationChangesSizeOfStackByOne() {
		stack.push(12);
		assertEquals(1, stack.size());
		stack.push(20);
		assertEquals(2, stack.size());
		stack.push(39);
		assertEquals(3, stack.size());
	}
	
	@Test
	public void testPopOperationChangesSizeOfStackByOneAndReturnsTopmostObject() throws EmptyMyStackException {
		stack.push(12);
		stack.push(34);
		stack.push(28);
		assertEquals((Integer)28, stack.pop());
		assertEquals(2, stack.size());		
		assertEquals((Integer) 34, stack.pop());
		assertEquals(1, stack.size());		
	}
	
	@Test(expected = EmptyMyStackException.class)
	public void testPopOperationOnEmptyStackThrowsException() throws EmptyMyStackException {
	     stack.pop();
	}
	
	@Test
	public void testPeekOperationReturnsTopmostObjectValueWithoutRemovingIt() throws EmptyMyStackException {
		stack.push(12);
		stack.push(34);
		stack.push(28);
		assertEquals((Integer) 28, stack.peek());
		assertEquals(3, stack.size());
		assertEquals((Integer) 28, stack.peek());
	}
	
	@Test(expected = EmptyMyStackException.class)
	public void testPeekOperationOnEmptyStackThrowsException() throws EmptyMyStackException {
		stack.peek();
	}
  	
	@After
	public void tearDown() {
		stack = null;
	}
}





