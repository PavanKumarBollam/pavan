package com.pspl.date.app;

public class DateUtils {
	private static final int FEBRUARY = 2;
	private static final int daysInMonth[] = new int[] {31,28,31,30,31,30,31,31,30,31,30,31};
	private static final int DECEMBER = 12;
	private static final int JANUARY = 1;
	private static final int DAYS_IN_LEAP_YEARS = 366;
	private static final int DAYS_IN_NON_LEAP_YEARS = 365;
	
	public static long duration(Date startDate, Date endDate) {
		if(sameYearAndMonth(startDate,endDate))
			return endDate.getDay() - startDate.getDay();
		else if(sameYear(startDate, endDate)) // but they are not on the same month if we come here.
			return remainingDaysInMonth(startDate) 
					+ daysInInterveningMonths(startDate, endDate) 
					+ leadingDaysInMonth(endDate);
		// when dates are in different years.
		else
			return remainingDaysInYear(startDate) + 
				daysInInterveningYears(startDate, endDate) + 
				leadingDaysInYear(endDate);
	}

	private static int leadingDaysInYear(Date endDate) {
		int result = 0;
		for(int month=JANUARY; month<endDate.getMonth(); month++)
			result += getDaysInMonth(month, endDate.getYear());
		result += leadingDaysInMonth(endDate);
		return result;		
	}

	private static int daysInInterveningYears(Date startDate, Date endDate) {
		int result = 0;
		for(int year=startDate.getYear()+1; year<endDate.getYear(); year++) {
			result += getDaysInYear(year);				
		}		
		return result;		
	}

	private static int getDaysInYear(int year) {
		int result = 0;
		if(isLeapYear(year))
			result += DAYS_IN_LEAP_YEARS;
		else
			result += DAYS_IN_NON_LEAP_YEARS;
		return result;
	}

	private static int remainingDaysInYear(Date startDate) {
		int result = remainingDaysInMonth(startDate);
		for(int month=startDate.getMonth()+1; month<=DECEMBER; month++)
			result += getDaysInMonth(month, startDate.getYear());
		return result;			
	}

	private static int daysInInterveningMonths(Date startDate, Date endDate) {
		int result = 0;
		for(int month=startDate.getMonth()+1; month<endDate.getMonth(); month++) {
			result += daysInMonth[month-1];
			if(isLeapYear(startDate.getYear()) && month==FEBRUARY)
				result++;
		}
		return result;
	}

	private static int leadingDaysInMonth(Date endDate) {
		return endDate.getDay();
	}

	private static int remainingDaysInMonth(Date startDate) {	
		return getDaysInMonth(startDate.getMonth(), startDate.getYear()) - startDate.getDay();
	}

	private static int getDaysInMonth(int month, int year) {
		int result = daysInMonth[month-1];
		if(isLeapYear(year) && month==FEBRUARY)
			result++;
		return result;
	}	

	//This method checks whether the year is leap year or not.
	private static boolean isLeapYear(int year) {
		if(year % 400 == 0) 
			return true;
		if(year % 100 == 0)
			return false;
		if(year % 4 == 0)
			return true;
		return false;
	}

	private static boolean sameYear(Date startDate, Date endDate) {
		return (startDate.getYear() == endDate.getYear());
	}

	private static boolean sameYearAndMonth(Date startDate, Date endDate) {
		return (startDate.getMonth() == endDate.getMonth() && startDate.getYear() == endDate.getYear());
	}
}
