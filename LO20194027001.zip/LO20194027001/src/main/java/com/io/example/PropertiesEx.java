package com.io.example;

import java.io.FileInputStream;

import java.io.InputStream;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class PropertiesEx {
	public static String browser;
	public static String url;
	static WebDriver driver;
	static Properties property = new Properties();
	public static void readProperties() {
		
		try {
			InputStream is = new FileInputStream(
					"C:\\Users\\home\\Downloads\\Microsoft.SkypeApp_kzf8qxf38zg5c!App\\module\\Module4\\src\\main\\java\\configuration.properties");
			property.load(is);
			System.out.println(property.getProperty("browser"));
		} catch (Exception e) {
			System.out.println(e);
		}
		}
		public static WebDriver setBrowser()
		{
			
			return driver = new ChromeDriver();
		}
		public static  void setBrowserConfig()
		{
			browser=property.getProperty("browser");
				if(browser.equals("chrome"));
					{
						System.setProperty("webdriver.chrome.driver","C:\\Users\\home\\Downloads\\Microsoft.SkypeApp_kzf8qxf38zg5c!App\\module\\Module4\\src\\main\\java\\chromedriver.exe");
					}
		}
		public static String urlprop()
		{
			return property.getProperty("url");
		}
	
		public static void endTest() {
			driver.quit();
		}
}
