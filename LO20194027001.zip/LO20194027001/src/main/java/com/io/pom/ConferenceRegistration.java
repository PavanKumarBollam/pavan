package com.io.pom;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;


public class ConferenceRegistration {
	
	WebDriver webdriver;
	public ConferenceRegistration(WebDriver webdriver) {
		this.webdriver=webdriver;
	}
	
	By firstName=By.name("txtFN");
	By lastName=By.name("txtLN");
	By email=By.name("Email");
	By contactNo=By.name("Phone");
	By noOfPeople=By.name("size");
	By buildingName=By.name("Address");
	By areaName=By.name("Address2");
	By city=By.name("city");
	By state=By.name("state");
	By conferenceAccess=By.name("memberStatus");
	
	public void giveFirstName() {
		System.out.println(webdriver.getTitle());
		webdriver.findElement(firstName).sendKeys("pavan");
	}
	
	public void giveLastName() {
		webdriver.findElement(lastName).sendKeys("bollam");
	}
	
	public void giveEmail() {
		webdriver.findElement(email).sendKeys("pa1@gmail.com");
	}
	
	public void giveContactNo() {
		webdriver.findElement(contactNo).sendKeys("8179122778");
	}
	
	public void giveNoOfPeople() {
		//driver.findElement(noOfPeople).sendKeys("");
		Select drpCountry = new Select(webdriver.findElement(noOfPeople));
		drpCountry.selectByVisibleText("1");
	}
	
	public void giveBuildingName() {
		webdriver.findElement(buildingName).sendKeys("ews 1065");
	}
	
	public void giveAreaName() {
		webdriver.findElement(areaName).sendKeys("lh colony");
	}
	
	public void giveCity() {
		Select drpCountry = new Select(webdriver.findElement(city));
		drpCountry.selectByVisibleText("Bangalore");
	}
	
	public void giveState() {
		Select drpCountry = new Select(webdriver.findElement(state));
		drpCountry.selectByVisibleText("Karnataka");
	}
	
	public void giveConferenceAccess() {
		WebElement radio1 = webdriver.findElement(conferenceAccess);
		radio1.click();
	}
	
	public void clickNext() {
		webdriver.findElement(By.xpath("//a[contains(text(),'Next')]")).click();		
		webdriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		webdriver.switchTo().alert().accept();
		
	}
}
