package com.service;

import java.util.ArrayList;

import com.bean.TdsMaster;

public interface TdsService {

	int register(TdsMaster tdsMaster);

	int update(TdsMaster tdsMaster);

	TdsMaster getById(int id);




}
