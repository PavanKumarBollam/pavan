package com.service;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.bean.TdsMaster;
import com.dao.TdsDao;

@Component("service")
@Service
@Transactional

public class TdsServiceImpl implements TdsService {

	@Autowired
	TdsDao tdsDao;
	
	
	@Override
	public int register(TdsMaster tdsMaster) {		
		return tdsDao.register(tdsMaster);
	}


	@Override
	public int update(TdsMaster tdsMaster) {
		return tdsDao.update(tdsMaster);
	}


	@Override
	public TdsMaster getById(int id) {
		
		return tdsDao.getById(id);
	}


	

}
