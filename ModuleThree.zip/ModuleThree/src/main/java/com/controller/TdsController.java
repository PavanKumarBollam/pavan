package com.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bean.TdsMaster;
import com.exception.IdNotFoundException;
import com.service.TdsService;

@RestController
public class TdsController {

@Autowired
	TdsService service;

@GetMapping("/")
public String display() {
	return "Displaying Tds";
}

@PostMapping("/register")
public ResponseEntity register(@RequestBody TdsMaster tdsMaster) {
	service.register(tdsMaster);
	return new ResponseEntity(HttpStatus.OK);
}

@PutMapping("/update")
public ResponseEntity update(@RequestBody TdsMaster tdsMaster) {
	service.update(tdsMaster);
	return new ResponseEntity(HttpStatus.OK);
}

@GetMapping("/getById")
public ResponseEntity getByid(@RequestBody int Id) throws IdNotFoundException {
	TdsMaster tdsMaster=service.getById(Id);
	if(tdsMaster==null) {
		throw new IdNotFoundException("ID Not Found Wrong Id: "+Id);
	}
	else
		return new ResponseEntity(tdsMaster,HttpStatus.OK);
}

  

}
