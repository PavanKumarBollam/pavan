package com.dao;

import java.util.ArrayList;

import com.bean.TdsMaster;

public interface TdsDao {

	int register(TdsMaster tdsMaster);

	int update(TdsMaster tdsMaster);

	TdsMaster getById(int id);

	

}
